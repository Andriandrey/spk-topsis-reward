			   <div class="input-group input-group-lg">
                <div class="input-group-btn">
                  <button type="button" class="btn btn-warning">Search <span class="fa fa-search"></span></button>
                </div>
                <!-- /btn-group -->
                <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
                   <input type="text" name="search_text" id="search_text" placeholder="Temukan data Peserta di sini" class="form-control input-lg" autofocus/>
                    <input type="hidden" name="MM_insert" value="form1" />
                </form>  
                
              </div>
              
              <div id="result"></div>
              <div style="clear:both"></div>             
 

			<br /> 