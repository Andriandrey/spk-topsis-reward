 
      <div class="row">
        <div class="col-md-12">
          <div class="box box-default">
            <div class="box-header with-border">
              <i class="fa fa-warning"></i>

              <h3 class="box-title">Manajemen Tabel</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
  				Silahkan masukkan perintah anda
  			</div>
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
	</div> 