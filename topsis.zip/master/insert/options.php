<option value="fa fa-500px" <?php if (!(strcmp("fa fa-500px"," fa fa-500px"))) {echo "SELECTED";} ?>> fa fa-500px</option>
<option value="fa fa-amazon" <?php if (!(strcmp("fa fa-amazon"," fa fa-amazon"))) {echo "SELECTED";} ?>> fa fa-amazon</option>
<option value="fa fa-balance-scale" <?php if (!(strcmp("fa fa-balance-scale"," fa fa-balance-scale"))) {echo "SELECTED";} ?>> fa fa-balance-scale</option>

<option value="fa fa-globe" <?php if (!(strcmp("fa fa-globe"," fa	 fa-globe"))) {echo "SELECTED";} ?>> fa fa-globe</option>
<option value="fa fa-graduation-cap" <?php if (!(strcmp("fa fa-graduation-cap"," fa	 fa-graduation-cap"))) {echo "SELECTED";} ?>> fa fa-graduation-cap</option>
<option value="fa fa-group" <?php if (!(strcmp("fa fa-group"," fa	 fa-group"))) {echo "SELECTED";} ?>> fa fa-group</option>
<option value="fa fa-volume-off" <?php if (!(strcmp("fa fa-volume-off"," fa	 fa-volume-off"))) {echo "SELECTED";} ?>> fa fa-volume-off</option>
<option value="fa fa-volume-up" <?php if (!(strcmp("fa fa-volume-up"," fa	 fa-volume-up"))) {echo "SELECTED";} ?>> fa fa-volume-up</option>
<option value="fa fa-warning" <?php if (!(strcmp("fa fa-warning"," fa	 fa-warning"))) {echo "SELECTED";} ?>> fa fa-warning</option>
<option value="fa fa-wheelchair" <?php if (!(strcmp("fa fa-wheelchair"," fa	 fa-wheelchair"))) {echo "SELECTED";} ?>> fa fa-wheelchair</option>
<option value="fa fa-wifi" <?php if (!(strcmp("fa fa-wifi"," fa	 fa-wifi"))) {echo "SELECTED";} ?>> fa fa-wifi</option>
